import { useState, useEffect, useMemo } from "react";
import { Search, MapPin, Star, X, Plus, Flame, Clock, ChevronLeft, Filter, Phone, ShieldCheck, RotateCw } from "lucide-react";

// ---------- Mock data ----------
const CUISINES = ["Sab", "North Indian", "South Indian", "Chinese", "Fast Food", "Bakery", "BBQ", "Desi Cafe"];

const RESTAURANTS = [
  { id: 1, name: "Karahi Point", cuisine: "North Indian", price: 2, spice: 4, rating: 4.6, reviews: 128, area: "Irving", hue: 18, hours: "12pm – 11pm", tags: ["Karahi", "Family Style", "Halal"] },
  { id: 2, name: "Dosa Junction", cuisine: "South Indian", price: 1, spice: 2, rating: 4.4, reviews: 96, area: "Richardson", hue: 45, hours: "8am – 10pm", tags: ["Dosa", "Filter Coffee", "Vegetarian"] },
  { id: 3, name: "Wok & Roll", cuisine: "Chinese", price: 2, spice: 3, rating: 4.1, reviews: 54, area: "Plano", hue: 355, hours: "11am – 10pm", tags: ["Noodles", "Manchurian", "Delivery"] },
  { id: 4, name: "Bun Kabab House", cuisine: "Fast Food", price: 1, spice: 3, rating: 4.3, reviews: 210, area: "Dallas", hue: 28, hours: "10am – 12am", tags: ["Kabab", "Rolls", "Quick Bite"] },
  { id: 5, name: "Meetha Bakery", cuisine: "Bakery", price: 1, spice: 0, rating: 4.8, reviews: 73, area: "Irving", hue: 330, hours: "9am – 9pm", tags: ["Sweets", "Cakes", "Chai"] },
  { id: 6, name: "Smoke & Sizzle", cuisine: "BBQ", price: 3, spice: 3, rating: 4.5, reviews: 88, area: "Frisco", hue: 12, hours: "1pm – 11pm", tags: ["Grill", "Kebabs", "Outdoor Seating"] },
  { id: 7, name: "Chai Adda", cuisine: "Desi Cafe", price: 1, spice: 1, rating: 4.7, reviews: 165, area: "Dallas", hue: 38, hours: "6am – 1am", tags: ["Chai", "Snacks", "Late Night"] },
  { id: 8, name: "Biryani Bhawan", cuisine: "North Indian", price: 2, spice: 4, rating: 4.2, reviews: 142, area: "Plano", hue: 22, hours: "11am – 11pm", tags: ["Biryani", "Nihari", "Buffet"] },
  { id: 9, name: "Idli Express", cuisine: "South Indian", price: 1, spice: 1, rating: 3.9, reviews: 41, area: "Richardson", hue: 50, hours: "8am – 9pm", tags: ["Idli", "Vada", "Breakfast"] },
];

const priceLabel = (n) => "$".repeat(n);
const flameRow = (n, max = 4) =>
  Array.from({ length: max }, (_, i) => i < n);

// ---------- Small components ----------
function TiffinRating({ value, size = 14 }) {
  // signature rating device: stacked "tiffin" boxes instead of plain stars
  const full = Math.round(value);
  return (
    <div className="flex items-center gap-[3px]" aria-label={`${value} out of 5`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <div
          key={i}
          style={{ width: size, height: size }}
          className={`rounded-[3px] border ${
            i < full ? "bg-[var(--accent)] border-[var(--accent)]" : "border-[var(--line)] bg-transparent"
          }`}
        />
      ))}
    </div>
  );
}

function SpiceMeter({ level }) {
  return (
    <div className="flex items-center gap-[2px]">
      {flameRow(level).map((filled, i) => (
        <Flame
          key={i}
          size={13}
          strokeWidth={2}
          className={filled ? "text-[var(--chili)]" : "text-[var(--line)]"}
          fill={filled ? "currentColor" : "none"}
        />
      ))}
    </div>
  );
}

function RestaurantCard({ r, onOpen }) {
  return (
    <button
      onClick={() => onOpen(r)}
      className="group text-left rounded-xl overflow-hidden border border-[var(--line)] bg-[var(--card)] hover:border-[var(--accent)] transition-colors duration-200 flex flex-col"
    >
      <div
        className="h-32 w-full relative flex items-end p-3"
        style={{
          background: `linear-gradient(135deg, hsl(${r.hue} 55% 22%), hsl(${r.hue} 45% 12%))`,
        }}
      >
        <span className="text-[11px] tracking-wide uppercase text-white/70 bg-black/25 px-2 py-1 rounded-full backdrop-blur-sm">
          {r.cuisine}
        </span>
      </div>
      <div className="p-4 flex flex-col gap-2 flex-1">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-[var(--font-display)] text-lg leading-tight text-[var(--ink)] group-hover:text-[var(--accent)] transition-colors">
            {r.name}
          </h3>
          <span className="text-xs font-[var(--font-mono)] text-[var(--muted)] shrink-0 pt-1">{priceLabel(r.price)}</span>
        </div>
        <div className="flex items-center gap-2">
          <TiffinRating value={r.rating} />
          <span className="text-xs font-[var(--font-mono)] text-[var(--muted)]">
            {r.rating.toFixed(1)} · {r.reviews}
          </span>
        </div>
        <div className="flex items-center justify-between mt-auto pt-2">
          <span className="flex items-center gap-1 text-xs text-[var(--muted)]">
            <MapPin size={12} /> {r.area}
          </span>
          <SpiceMeter level={r.spice} />
        </div>
      </div>
    </button>
  );
}

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:3001";

function toE164(raw) {
  const digits = raw.replace(/\D/g, "");
  if (raw.trim().startsWith("+")) return `+${digits}`;
  if (digits.length === 10) return `+1${digits}`; // assume US number
  return `+${digits}`;
}

function PhoneGate({ onVerified }) {
  const [phone, setPhone] = useState("");
  const [stage, setStage] = useState("enter-phone"); // enter-phone | enter-otp | verified
  const [otpInput, setOtpInput] = useState("");
  const [error, setError] = useState("");
  const [resendIn, setResendIn] = useState(0);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (resendIn <= 0) return;
    const t = setInterval(() => setResendIn((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(t);
  }, [resendIn]);

  const sendOtp = async (e) => {
    e.preventDefault();
    const digits = phone.replace(/\D/g, "");
    if (digits.length < 10) {
      setError("Sahi phone number daalein (10 digit).");
      return;
    }
    setError("");
    setBusy(true);
    try {
      const res = await fetch(`${API_URL}/api/send-otp`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: toE164(phone) }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "OTP nahi bheja ja saka.");
      setStage("enter-otp");
      setResendIn(30);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  const verifyOtp = async (e) => {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const res = await fetch(`${API_URL}/api/verify-otp`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: toE164(phone), code: otpInput.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "OTP match nahi hua.");
      setStage("verified");
      onVerified({ phone: data.phone, token: data.token });
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  if (stage === "enter-phone") {
    return (
      <form onSubmit={sendOtp} className="border border-[var(--line)] rounded-xl p-4 flex flex-col gap-3 bg-[var(--card)]">
        <div className="flex items-center gap-2 text-sm font-medium text-[var(--ink)]">
          <Phone size={15} className="text-[var(--accent)]" />
          Review likhne se pehle phone verify karein
        </div>
        <input
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          placeholder="+1 214 555 0132"
          inputMode="tel"
          className="bg-transparent border border-[var(--line)] rounded-lg px-3 py-2 text-sm text-[var(--ink)] focus:outline-none focus:border-[var(--accent)]"
        />
        {error && <p className="text-xs text-[var(--chili)]">{error}</p>}
        <button
          type="submit"
          disabled={busy}
          className="self-end flex items-center gap-1.5 bg-[var(--accent)] text-[var(--ink-on-accent)] text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90 transition-opacity disabled:opacity-50"
        >
          {busy ? "Bhej rahe hain..." : "OTP bhejein"}
        </button>
        <p className="text-xs text-[var(--muted)] leading-relaxed">
          Fake reviews rokne ke liye har naya reviewer ek baar apna number verify karta hai.
        </p>
      </form>
    );
  }

  if (stage === "enter-otp") {
    return (
      <form onSubmit={verifyOtp} className="border border-[var(--line)] rounded-xl p-4 flex flex-col gap-3 bg-[var(--card)]">
        <div className="flex items-center gap-2 text-sm font-medium text-[var(--ink)]">
          <ShieldCheck size={15} className="text-[var(--accent)]" />
          {phone} pe bheja gaya code daalein
        </div>
        <input
          value={otpInput}
          onChange={(e) => setOtpInput(e.target.value)}
          placeholder="4-digit code"
          inputMode="numeric"
          maxLength={4}
          className="bg-transparent border border-[var(--line)] rounded-lg px-3 py-2 text-sm text-[var(--ink)] tracking-[0.3em] focus:outline-none focus:border-[var(--accent)]"
        />
        {error && <p className="text-xs text-[var(--chili)]">{error}</p>}
        <div className="flex items-center justify-between">
          <button
            type="button"
            disabled={resendIn > 0 || busy}
            onClick={sendOtp}
            className="flex items-center gap-1 text-xs text-[var(--muted)] disabled:opacity-40 hover:text-[var(--accent)]"
          >
            <RotateCw size={12} /> {resendIn > 0 ? `Dobara bhejein (${resendIn}s)` : "Code dobara bhejein"}
          </button>
          <button
            type="submit"
            disabled={busy}
            className="flex items-center gap-1.5 bg-[var(--accent)] text-[var(--ink-on-accent)] text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90 transition-opacity disabled:opacity-50"
          >
            {busy ? "Verify ho raha hai..." : "Verify karein"}
          </button>
        </div>
      </form>
    );
  }

  return null;
}

function ReviewForm({ onSubmit, verified }) {
  const [author, setAuthor] = useState("");
  const [rating, setRating] = useState(5);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    setBusy(true);
    setError("");
    try {
      await onSubmit({ author: author.trim() || "Mehmaan", rating, text: text.trim() });
      setAuthor("");
      setText("");
      setRating(5);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <form onSubmit={submit} className="border border-[var(--line)] rounded-xl p-4 flex flex-col gap-3 bg-[var(--card)]">
      <div className="flex items-center justify-between">
        <span className="flex items-center gap-1.5 text-sm font-medium text-[var(--ink)]">
          <ShieldCheck size={14} className="text-[var(--accent)]" /> Number verified ({verified.phone})
        </span>
        <div className="flex gap-1">
          {[1, 2, 3, 4, 5].map((n) => (
            <button
              type="button"
              key={n}
              onClick={() => setRating(n)}
              className="p-0.5"
              aria-label={`${n} rating`}
            >
              <Star
                size={18}
                className={n <= rating ? "text-[var(--accent)]" : "text-[var(--line)]"}
                fill={n <= rating ? "currentColor" : "none"}
              />
            </button>
          ))}
        </div>
      </div>
      <input
        value={author}
        onChange={(e) => setAuthor(e.target.value)}
        placeholder="Aapka naam (optional)"
        className="bg-transparent border border-[var(--line)] rounded-lg px-3 py-2 text-sm text-[var(--ink)] focus:outline-none focus:border-[var(--accent)]"
      />
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Khana kaisa tha? Service, ambience, kuch bhi share karein..."
        rows={3}
        className="bg-transparent border border-[var(--line)] rounded-lg px-3 py-2 text-sm text-[var(--ink)] focus:outline-none focus:border-[var(--accent)] resize-none"
      />
      {error && <p className="text-xs text-[var(--chili)]">{error}</p>}
      <button
        type="submit"
        disabled={busy}
        className="self-end flex items-center gap-1.5 bg-[var(--accent)] text-[var(--ink-on-accent)] text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90 transition-opacity disabled:opacity-50"
      >
        <Plus size={15} /> {busy ? "Post ho raha hai..." : "Review post karein"}
      </button>
    </form>
  );
}

function RestaurantDetail({ r, onBack }) {
  const [verified, setVerified] = useState(null); // { phone, token }
  const [reviews, setReviews] = useState([]);
  const [loadingReviews, setLoadingReviews] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoadingReviews(true);
    fetch(`${API_URL}/api/reviews/${r.id}`)
      .then((res) => res.json())
      .then((data) => {
        if (!cancelled) setReviews(Array.isArray(data) ? data : []);
      })
      .catch(() => {})
      .finally(() => !cancelled && setLoadingReviews(false));
    return () => {
      cancelled = true;
    };
  }, [r.id]);

  const addReview = async (rv) => {
    const res = await fetch(`${API_URL}/api/reviews/${r.id}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${verified.token}`,
      },
      body: JSON.stringify(rv),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Review post nahi ho saka.");
    setReviews((prev) => [data, ...prev]);
  };

  const avgFromReviews = reviews.length
    ? reviews.reduce((s, rv) => s + rv.rating, 0) / reviews.length
    : r.rating;

  return (
    <div className="max-w-2xl mx-auto">
      <button
        onClick={onBack}
        className="flex items-center gap-1 text-sm text-[var(--muted)] hover:text-[var(--accent)] mb-4 transition-colors"
      >
        <ChevronLeft size={16} /> Sab restaurants
      </button>

      <div
        className="h-40 rounded-xl mb-5 flex items-end p-5"
        style={{ background: `linear-gradient(135deg, hsl(${r.hue} 55% 22%), hsl(${r.hue} 45% 12%))` }}
      >
        <div>
          <span className="text-[11px] tracking-wide uppercase text-white/70">{r.cuisine}</span>
          <h1 className="font-[var(--font-display)] text-3xl text-white leading-tight">{r.name}</h1>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-x-5 gap-y-2 mb-4">
        <div className="flex items-center gap-2">
          <TiffinRating value={avgFromReviews} size={16} />
          <span className="text-sm font-[var(--font-mono)] text-[var(--ink)]">{avgFromReviews.toFixed(1)}</span>
          <span className="text-sm text-[var(--muted)]">({reviews.length} reviews)</span>
        </div>
        <span className="text-sm text-[var(--muted)]">{priceLabel(r.price)}</span>
        <span className="flex items-center gap-1 text-sm text-[var(--muted)]"><MapPin size={13} />{r.area}</span>
        <span className="flex items-center gap-1 text-sm text-[var(--muted)]"><Clock size={13} />{r.hours}</span>
        <SpiceMeter level={r.spice} />
      </div>

      <div className="flex flex-wrap gap-2 mb-6">
        {r.tags.map((t) => (
          <span key={t} className="text-xs px-2.5 py-1 rounded-full border border-[var(--line)] text-[var(--muted)]">
            {t}
          </span>
        ))}
      </div>

      <div className="mb-6">
        {verified ? (
          <ReviewForm verified={verified} onSubmit={addReview} />
        ) : (
          <PhoneGate onVerified={setVerified} />
        )}
      </div>

      <div className="flex flex-col gap-3">
        <h2 className="font-[var(--font-display)] text-lg text-[var(--ink)]">Reviews</h2>
        {loadingReviews && <p className="text-sm text-[var(--muted)]">Load ho raha hai...</p>}
        {!loadingReviews && reviews.length === 0 && (
          <p className="text-sm text-[var(--muted)]">Abhi koi review nahi hai — sabse pehle aap likhein.</p>
        )}
        {reviews.map((rv) => (
          <div key={rv.id} className="border-b border-[var(--line)] pb-3 last:border-none">
            <div className="flex items-center justify-between mb-1">
              <span className="flex items-center gap-1 text-sm font-medium text-[var(--ink)]">
                {rv.author}
                <ShieldCheck size={12} className="text-[var(--accent)]" aria-label="Phone verified" />
              </span>
              <span className="text-xs text-[var(--muted)]">{new Date(rv.date).toLocaleDateString()}</span>
            </div>
            <TiffinRating value={rv.rating} size={11} />
            <p className="text-sm text-[var(--muted)] mt-1.5 leading-relaxed">{rv.text}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function ZaikaApp() {
  const [query, setQuery] = useState("");
  const [cuisine, setCuisine] = useState("Sab");
  const [selected, setSelected] = useState(null);

  const filtered = useMemo(() => {
    return RESTAURANTS.filter((r) => {
      const matchesCuisine = cuisine === "Sab" || r.cuisine === cuisine;
      const q = query.trim().toLowerCase();
      const matchesQuery =
        !q || r.name.toLowerCase().includes(q) || r.tags.some((t) => t.toLowerCase().includes(q));
      return matchesCuisine && matchesQuery;
    });
  }, [query, cuisine]);

  return (
    <div
      className="min-h-full w-full"
      style={{
        "--ink": "#F3EADA",
        "--muted": "#B9A98F",
        "--card": "#241D17",
        "--line": "#3A3025",
        "--bg": "#171310",
        "--accent": "#D9A02C",
        "--chili": "#C1442C",
        "--ink-on-accent": "#1A1410",
        "--font-display": "'Fraunces', serif",
        "--font-body": "'Work Sans', sans-serif",
        "--font-mono": "'JetBrains Mono', monospace",
        background: "var(--bg)",
        fontFamily: "var(--font-body)",
        color: "var(--ink)",
      }}
    >
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link
        href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600&family=Work+Sans:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap"
        rel="stylesheet"
      />

      {/* Header */}
      <header className="border-b border-[var(--line)] sticky top-0 z-10 backdrop-blur-md" style={{ background: "rgba(23,19,16,0.9)" }}>
        <div className="max-w-5xl mx-auto px-5 py-4 flex items-center justify-between gap-4">
          <div className="flex items-baseline gap-2">
            <span className="font-[var(--font-display)] text-2xl text-[var(--accent)] font-semibold">Zaika</span>
            <span className="text-xs text-[var(--muted)] font-[var(--font-mono)] hidden sm:inline">Dallas–Fort Worth</span>
          </div>
          {!selected && (
            <div className="flex items-center gap-2 flex-1 max-w-sm">
              <div className="flex items-center gap-2 border border-[var(--line)] rounded-lg px-3 py-2 flex-1 focus-within:border-[var(--accent)] transition-colors">
                <Search size={15} className="text-[var(--muted)] shrink-0" />
                <input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Restaurant ya dish dhoondhein..."
                  className="bg-transparent text-sm w-full focus:outline-none placeholder:text-[var(--muted)] text-[var(--ink)]"
                />
              </div>
            </div>
          )}
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-5 py-6">
        {selected ? (
          <RestaurantDetail r={selected} onBack={() => setSelected(null)} />
        ) : (
          <>
            <div className="mb-5">
              <h1 className="font-[var(--font-display)] text-3xl mb-1 text-[var(--ink)]">Aaj kahan khana hai?</h1>
              <p className="text-sm text-[var(--muted)]">{filtered.length} jagah mili DFW area mein</p>
            </div>

            <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-1 -mx-1 px-1">
              <Filter size={14} className="text-[var(--muted)] shrink-0" />
              {CUISINES.map((c) => (
                <button
                  key={c}
                  onClick={() => setCuisine(c)}
                  className={`shrink-0 text-xs px-3 py-1.5 rounded-full border transition-colors ${
                    cuisine === c
                      ? "bg-[var(--accent)] border-[var(--accent)] text-[var(--ink-on-accent)]"
                      : "border-[var(--line)] text-[var(--muted)] hover:border-[var(--accent)]"
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>

            {filtered.length === 0 ? (
              <div className="text-center py-16 text-[var(--muted)]">
                <p className="text-sm">Koi match nahi mila. Dusra search try karein.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {filtered.map((r) => (
                  <RestaurantCard key={r.id} r={r} onOpen={setSelected} />
                ))}
              </div>
            )}
          </>
        )}
      </main>

      <footer className="border-t border-[var(--line)] mt-8">
        <div className="max-w-5xl mx-auto px-5 py-5 text-xs text-[var(--muted)] flex items-center justify-between">
          <span>Zaika — local reviews, apni zabaan mein.</span>
          <span className="font-[var(--font-mono)]">Prototype</span>
        </div>
      </footer>
    </div>
  );
}
