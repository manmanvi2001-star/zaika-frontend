# Zaika Backend — Phone OTP + Reviews API

Express server that verifies US phone numbers via **Twilio Verify** before
accepting a review. Pairs with the `zaika.jsx` frontend.

## 1. Twilio setup (one-time, do this first)

1. Create a Twilio account: https://www.twilio.com/try-twilio
2. In the Console, go to **Verify > Services** and click **Create new Service**.
   Copy the **Service SID** (starts with `VA...`).
3. Copy your **Account SID** and **Auth Token** from the Console dashboard.
4. **Important for the US:** register for **10DLC (A2P messaging)** so
   carriers don't block your messages. Twilio's console walks you through
   brand + campaign registration under **Messaging > Regulatory Compliance**.
   Verify API messages typically use Twilio's shared short codes/verify
   pool, but check current Twilio docs for US SMS compliance requirements
   before going live, since rules do change.

## 2. Install

```bash
cd zaika-backend
npm install
cp .env.example .env
```

Fill in `.env` with your Twilio SID/token/service SID, and generate a
`SERVER_SECRET`:

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

## 3. Run

```bash
npm start
# Zaika backend listening on http://localhost:3001
```

## 4. API endpoints

| Method | Path | Auth | Body | Purpose |
|---|---|---|---|---|
| POST | `/api/send-otp` | none | `{ "phone": "+12145550132" }` | Sends SMS OTP |
| POST | `/api/verify-otp` | none | `{ "phone": "+12145550132", "code": "1234" }` | Checks OTP, returns a 30-min token |
| GET | `/api/reviews/:restaurantId` | none | — | List reviews for a restaurant |
| POST | `/api/reviews/:restaurantId` | `Authorization: Bearer <token>` | `{ "author", "rating", "text" }` | Post a review (one per verified phone) |

Phone numbers must be in **E.164 format** (e.g. `+12145550132`).

## 5. Connect the frontend

In `zaika.jsx`, replace the `PhoneGate` component's demo logic:
- `sendOtp` → `fetch('http://localhost:3001/api/send-otp', { method: 'POST', body: JSON.stringify({ phone }) })`
- `verifyOtp` → `fetch('http://localhost:3001/api/verify-otp', ...)`, save the returned `token`
- When posting a review, send `Authorization: Bearer <token>` and call
  `POST /api/reviews/:restaurantId` instead of local state.

## Notes on abuse prevention already built in

- Rate limiting on OTP endpoints (5 requests / 15 min per IP)
- One review per verified phone number per restaurant
- Verification tokens expire after 30 minutes and are HMAC-signed
- Phone numbers are never returned in public API responses

## Going to production

- Swap the in-memory `Map` for a real database (Postgres/MongoDB/etc.)
- Put this behind HTTPS (required for Twilio + real users)
- Move `SERVER_SECRET` and Twilio credentials into a proper secrets manager
- Consider Twilio's fraud/geo-permission settings to restrict which
  countries can request OTPs, since you're only targeting the US
