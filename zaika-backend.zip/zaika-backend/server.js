require("dotenv").config();
const express = require("express");
const cors = require("cors");
const crypto = require("crypto");
const rateLimit = require("express-rate-limit");
const twilio = require("twilio");

const {
  TWILIO_ACCOUNT_SID,
  TWILIO_AUTH_TOKEN,
  TWILIO_VERIFY_SERVICE_SID,
  SERVER_SECRET,
  ALLOWED_ORIGINS,
  PORT,
} = process.env;

if (!TWILIO_ACCOUNT_SID || !TWILIO_AUTH_TOKEN || !TWILIO_VERIFY_SERVICE_SID || !SERVER_SECRET) {
  console.error(
    "Missing required env vars. Copy .env.example to .env and fill in Twilio + SERVER_SECRET values."
  );
  process.exit(1);
}

const twilioClient = twilio(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);

const app = express();
app.use(express.json());
app.use(
  cors({
    origin: (ALLOWED_ORIGINS || "").split(",").map((s) => s.trim()).filter(Boolean),
  })
);

// ---- In-memory review store (swap for a real database in production) ----
const reviewsByRestaurant = new Map();

// ---- Rate limiting: OTP endpoints are the main abuse target ----
const otpLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // 5 OTP requests per phone-agnostic IP window
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Bahut zyada requests. Thodi der baad try karein." },
});

// ---- Helpers: sign/verify a short-lived "phone verified" token ----
// Token format: base64url(payloadJSON).hexHmac
function signToken(payload) {
  const payloadStr = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const sig = crypto.createHmac("sha256", SERVER_SECRET).update(payloadStr).digest("hex");
  return `${payloadStr}.${sig}`;
}

function verifyToken(token) {
  if (!token || typeof token !== "string" || !token.includes(".")) return null;
  const [payloadStr, sig] = token.split(".");
  const expectedSig = crypto.createHmac("sha256", SERVER_SECRET).update(payloadStr).digest("hex");
  if (sig !== expectedSig) return null;
  try {
    const payload = JSON.parse(Buffer.from(payloadStr, "base64url").toString("utf8"));
    if (payload.exp < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}

function requireVerifiedPhone(req, res, next) {
  const auth = req.headers.authorization || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : null;
  const payload = verifyToken(token);
  if (!payload) {
    return res.status(401).json({ error: "Phone verification required ya expire ho gayi. Dobara verify karein." });
  }
  req.verifiedPhone = payload.phone;
  next();
}

function isValidE164(phone) {
  return /^\+[1-9]\d{6,14}$/.test(phone);
}

// ---- Routes ----

// 1. Send OTP to a phone number via Twilio Verify
app.post("/api/send-otp", otpLimiter, async (req, res) => {
  const { phone } = req.body || {};
  if (!phone || !isValidE164(phone)) {
    return res.status(400).json({ error: "Phone number E.164 format mein bhejein, jaise +12145550132" });
  }

  try {
    const verification = await twilioClient.verify.v2
      .services(TWILIO_VERIFY_SERVICE_SID)
      .verifications.create({ to: phone, channel: "sms" });

    return res.json({ status: verification.status }); // "pending"
  } catch (err) {
    console.error("send-otp error:", err.message);
    return res.status(502).json({ error: "OTP bhejne mein dikkat aayi. Baad mein try karein." });
  }
});

// 2. Check the OTP code the user typed in
app.post("/api/verify-otp", otpLimiter, async (req, res) => {
  const { phone, code } = req.body || {};
  if (!phone || !isValidE164(phone) || !code) {
    return res.status(400).json({ error: "Phone aur code dono chahiye." });
  }

  try {
    const check = await twilioClient.verify.v2
      .services(TWILIO_VERIFY_SERVICE_SID)
      .verificationChecks.create({ to: phone, code });

    if (check.status !== "approved") {
      return res.status(400).json({ error: "OTP galat hai." });
    }

    // Issue a short-lived (30 min) signed token proving this phone is verified.
    const token = signToken({ phone, exp: Date.now() + 30 * 60 * 1000 });
    return res.json({ token, phone });
  } catch (err) {
    console.error("verify-otp error:", err.message);
    return res.status(502).json({ error: "Verify karne mein dikkat aayi. Dobara try karein." });
  }
});

// 3. Get reviews for a restaurant — public, no auth needed
app.get("/api/reviews/:restaurantId", (req, res) => {
  const list = reviewsByRestaurant.get(req.params.restaurantId) || [];
  res.json(list);
});

// 4. Post a review — requires a valid "verified phone" token from step 2
app.post("/api/reviews/:restaurantId", requireVerifiedPhone, (req, res) => {
  const { author, rating, text } = req.body || {};
  const ratingNum = Number(rating);

  if (!text || !text.trim()) {
    return res.status(400).json({ error: "Review text zaroori hai." });
  }
  if (!Number.isInteger(ratingNum) || ratingNum < 1 || ratingNum > 5) {
    return res.status(400).json({ error: "Rating 1 se 5 ke beech honi chahiye." });
  }

  const restaurantId = req.params.restaurantId;
  const list = reviewsByRestaurant.get(restaurantId) || [];

  // One review per verified phone per restaurant — prevents repeat spam.
  if (list.some((r) => r.phone === req.verifiedPhone)) {
    return res.status(409).json({ error: "Is number se pehle hi review post ho chuka hai." });
  }

  const review = {
    id: crypto.randomUUID(),
    author: (author || "Mehmaan").trim().slice(0, 60),
    rating: ratingNum,
    text: text.trim().slice(0, 1000),
    date: new Date().toISOString(),
    phone: req.verifiedPhone, // kept server-side only, don't expose to other clients
    verified: true,
  };

  list.unshift(review);
  reviewsByRestaurant.set(restaurantId, list);

  // Don't leak the phone number back in the public response.
  const { phone, ...publicReview } = review;
  res.status(201).json(publicReview);
});

app.get("/health", (_req, res) => res.json({ ok: true }));

const port = PORT || 3001;
app.listen(port, () => {
  console.log(`Zaika backend listening on http://localhost:${port}`);
});
