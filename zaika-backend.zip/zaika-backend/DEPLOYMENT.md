# Zaika — Complete Deployment Checklist

Follow in order. Each step tells you exactly where to click.

---

## Step 1 — Buy a domain (~$10–15/year)

1. Go to **Namecheap.com** or **Google Domains / Squarespace Domains**
2. Search your desired name (e.g. `zaikadfw.com`)
3. Buy it (credit card required — this is real money, ~$10-15/yr)
4. You'll manage DNS records for this domain in Steps 3 & 4

---

## Step 2 — Twilio (SMS OTP)

1. Sign up: https://www.twilio.com/try-twilio (free trial gives test credit)
2. Console → **Verify → Services → Create new Service** → name it "Zaika"
   → copy the **Service SID** (starts `VA...`)
3. Console home page → copy **Account SID** and **Auth Token**
4. Console → **Messaging → Regulatory Compliance → 10DLC** → register your
   brand + campaign (required for sending SMS to US numbers reliably).
   This can take 1–3 business days for approval — do this early.
5. Keep these 3 values handy for Step 3: Account SID, Auth Token, Verify Service SID

---

## Step 3 — Deploy the backend on Render

1. Push the `zaika-backend` folder to a GitHub repo (create one at
   github.com/new, then `git init && git add . && git commit -m "init" && git push`)
2. Go to https://render.com → sign up (free) → **New → Web Service**
3. Connect your GitHub repo, select the `zaika-backend` folder
4. Render auto-detects `render.yaml`. If not, set manually:
   - Build command: `npm install`
   - Start command: `npm start`
5. Under **Environment**, add these variables (from Step 2):
   - `TWILIO_ACCOUNT_SID`
   - `TWILIO_AUTH_TOKEN`
   - `TWILIO_VERIFY_SERVICE_SID`
   - `SERVER_SECRET` — generate with:
     `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`
   - `ALLOWED_ORIGINS` — set this AFTER Step 4, to your Vercel URL
     (e.g. `https://zaikadfw.com`)
6. Deploy. Render gives you a URL like `https://zaika-backend.onrender.com`
   — copy it, you need it in Step 4.

Note: Render's free tier sleeps after inactivity — first request after
idle takes ~30s to wake up. Fine for testing; upgrade to a paid instance
($7/mo) before real users depend on it.

---

## Step 4 — Deploy the frontend on Vercel

1. Push the `zaika-frontend` folder to a GitHub repo (same process as Step 3)
2. Go to https://vercel.com → sign up (free) → **Add New → Project**
3. Import the `zaika-frontend` repo. Vercel auto-detects Vite — leave
   build settings as default (`npm run build`, output dir `dist`)
4. Under **Environment Variables**, add:
   - `VITE_API_URL` = your Render backend URL from Step 3
     (e.g. `https://zaika-backend.onrender.com`)
5. Deploy. Vercel gives you a URL like `zaika-frontend.vercel.app` — test
   the site here first before connecting your custom domain.

---

## Step 5 — Connect your domain

1. In Vercel: Project → **Settings → Domains** → add your domain
   (e.g. `zaikadfw.com`)
2. Vercel shows you DNS records to add (usually an `A` record or `CNAME`)
3. Go to your domain registrar (Namecheap etc.) → **DNS settings** →
   add the records Vercel gave you
4. Wait 10 min – a few hours for DNS to propagate
5. Back in Render: update `ALLOWED_ORIGINS` env var to your real domain
   (e.g. `https://zaikadfw.com`) and redeploy, so the backend accepts
   requests from your live site

---

## Step 6 — Test end to end

1. Visit your live domain
2. Open a restaurant → try posting a review
3. Enter your real phone number → you should receive a real SMS OTP
4. Enter the code → post the review → refresh the page → review should
   still be there (confirms backend + database... well, in-memory store
   for now, see note below)

---

## Known limitation to fix before real users

The backend currently stores reviews **in memory** — they disappear if
the Render service restarts. For a real launch, swap the `Map` in
`server.js` for a real database. Easiest options:
- **Render Postgres** (free tier available, stays in the same dashboard)
- **Supabase** (free tier, also gives you an admin UI)

Ask if you want this wired in — it's a moderate change to `server.js`
(swap the in-memory `Map` calls for SQL queries) plus a couple of new
env vars for the database connection string.

---

## Rough cost summary

| Item | Cost |
|---|---|
| Domain | ~$10–15/year |
| Twilio | Pay-per-SMS after trial credit (~$0.0079/SMS in the US) |
| Render (backend) | Free to start, $7/mo to avoid cold starts |
| Vercel (frontend) | Free for this scale |
